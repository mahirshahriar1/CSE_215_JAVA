import java.util.Scanner;

public class Task01B {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter n: ");
        int n = sc.nextInt();
        sc.close();

        /*
         * Series is look like
         * 1!/1 + 2!/2 + 3!/3 + 4!/4 + ... + n!/n
         * We can actually simplify a bit
         * 1 + 1! + 2! + 3! + ... + n-1!
         */

        System.out.println("Result : " + sumSeries(n));
    }

    public static double sumSeries(int n) {
        double sum = 1, fact = 1;
        if (n == 1)
            return 1;
        for (int i = 1; i < n; i++) {
            fact = fact * i;
            sum += fact;
        }
        return sum;
    }

}
