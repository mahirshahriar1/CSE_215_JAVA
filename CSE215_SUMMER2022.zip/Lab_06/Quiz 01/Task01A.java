import java.util.Scanner;

public class Task01A {

    public static void main(String[] args) {

        int base, exp;
        System.out.println("Enter a base number: ");
        Scanner sc = new Scanner(System.in);
        base = sc.nextInt();
        System.out.println("Enter an exponent: ");
        exp = sc.nextInt();
        sc.close();
        System.out.println(base + "^" + exp + " : " + power(base, exp));

    }

    public static double power(int base, int exp) {
        double result = 1;
        boolean expIsPositive = true;

        if (exp < 0) {
            exp = -exp;
            expIsPositive = false;
        }

        while (exp != 0) {
            result *= base;
            --exp;
        }
        if (!expIsPositive)
            return 1 / result;
        return result;

    }

}