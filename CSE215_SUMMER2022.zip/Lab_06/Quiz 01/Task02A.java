import java.util.Scanner;

public class Task02A {
    public static void main(String[] args) {

        int n1, n2;

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter n1: ");
        n1 = sc.nextInt();

        System.out.println("Enter n2: ");
        n2 = sc.nextInt();
        sc.close();

        for (int i = n1; i <= n2; i++) {
            if (isArmstrong(i))
                System.out.printf("%d ", i);
        }

        System.out.println();
    }

    // method to check Armstrong number
    public static boolean isArmstrong(int num) {
        int digit, sum = 0;
        int n = num;
        while (n != 0) {
            digit = n % 10;
            sum += digit * digit * digit;
            n /= 10;
        }
        if (sum == num)
            return true;

        return false;
    }

}
