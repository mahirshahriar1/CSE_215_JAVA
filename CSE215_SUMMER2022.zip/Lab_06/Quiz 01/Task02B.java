import java.util.Scanner;

public class Task02B {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter n1: ");
        int n1 = sc.nextInt();
        System.out.print("Enter n2: ");
        int n2 = sc.nextInt();
        sc.close();

        for (int i = n1; i <= n2; i++) {
            if (isPerfect(i))
                System.out.printf("%d ", i);
        }

        System.out.println();
    }

    public static boolean isPerfect(int num) {

        boolean isPerfect = false;
        int n = num, sum = 0;

        for (int i = 1; i < n; i++) {
            if (n % i == 0)
                sum += i;
        }
        if (sum == num)
            isPerfect = true;

        return isPerfect;
    }
}
