package Lab_05.tasks;

import java.util.Scanner;

public class Task02 {
    public static void main(String[] args) {
        int N;
        Scanner sc = new Scanner(System.in);
        System.out.print("N = ");
        N = sc.nextInt();
        int a[][] = new int[N][N];

        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                a[i][j] = sc.nextInt();

        sc.close();

        int sum = 0;
        for (int i = 0; i < N; i++)
            sum += a[i][i];

        System.out.println(sum);
    }
}
