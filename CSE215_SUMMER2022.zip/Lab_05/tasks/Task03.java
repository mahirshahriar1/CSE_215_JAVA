package Lab_05.tasks;

import java.util.Scanner;

public class Task03 {
    public static void main(String[] args) {
        int m, n;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter rows: ");
        m = sc.nextInt();
        System.out.print("Enter columns: ");
        n = sc.nextInt();
        int a[][] = new int[m][n];
        int transpose[][] = new int[n][m];

        System.out.println("Enter Matrix Elements: ");
        for (int i = 0; i < m; i++)
            for (int j = 0; j < n; j++)
                a[i][j] = sc.nextInt();

        sc.close();

        for (int i = 0; i < m; ++i)
            for (int j = 0; j < n; ++j) {
                transpose[j][i] = a[i][j];
            }

        System.out.println("Transpose : ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(transpose[i][j] + "\t");
            }
            System.out.println();
        }
    }
}