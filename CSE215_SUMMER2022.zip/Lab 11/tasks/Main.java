
public class Main {

	public static void main(String[] args) {
		Point p = new Point();
		Point q = new Point(3, 4);
		
		Line a = new Line(p, q);
		Line b = new Line(0, 0, 3, 4);
		
		System.out.println("Distance: " + a.getLength());
		System.out.println("Distance: " + b.getLength());
	}

}
