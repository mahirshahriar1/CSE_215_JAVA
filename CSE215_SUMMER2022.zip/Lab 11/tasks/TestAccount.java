
public class TestAccount {

	public static void main(String[] args) {
		Account a1 = new Account(1510091);
		Account a2 = new Account(1620096, 5000.0);
		
		System.out.println(a1);
		System.out.println(a2);
		System.out.println();
		
		a1.credit(10000);
		a2.debit(2000);
		
		System.out.println(a1);
		System.out.println(a2);
	}

}
