import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

public class Main {

    public static void main(String[] args) {

        // JFrame = a GUI window to add components to

        JFrame frame = new JFrame(); // creates a frame
        frame.setTitle("JFrame title goes here"); // sets title of frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // exit from application
        frame.setResizable(false); // prevent frame from being resized
        // frame.setSize(420, 420); // sets the width, and height of frame
        frame.setBounds(100, 100, 420, 420);// sets the x, y, width and height of a frame
        frame.setVisible(true); // make frame visible
        frame.getContentPane().setBackground(new Color(0x123456)); // change color of background

        JPanel panel = new JPanel(); // creates a panel component
        panel.setBackground(new Color(0, 204, 153)); // sets background color
        panel.setBorder(new LineBorder(new Color(0, 0, 0), 2, true)); // a a border of 2 pixel black
        panel.setBounds(100, 100, 380, 380); // sets the width, and height of frame
        frame.getContentPane().add(panel); // add panel to Frame
        panel.setLayout(null); // absolute positioning

        JLabel lblNewLabel = new JLabel("Welcome Screen");
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setForeground(new Color(204, 0, 153));
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblNewLabel.setBounds(84, 11, 238, 29);
        panel.add(lblNewLabel);

    }
}