package task;

public class Main {

	public static void main(String[] args) {
		Shape s;

		s = new Shape();
		System.out.println(s.toString());

		s = new Circle(5, "Red", true);
		System.out.println(s.toString());

		s = new Rectangle(4, 5, "Blue", true);
		System.out.println(s.toString());

		s = new Square(5, "Green", true);
		System.out.println(s.toString());
	}

}
