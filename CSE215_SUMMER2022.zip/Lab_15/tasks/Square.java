package task;

public class Square extends Rectangle {

	public Square() {
		super();
	}
	
	public Square(double side) {
		super(side, side);
	}

	public Square(double side, String color, boolean filled) {
		super(side, side, color, filled);
	}

	public double getSide() {
		return super.getWidth();
	}

	public void setSide(double side) {
		super.setWidth(side);
		super.setHeight(side);
	}
	
	public double getPerimeter() {
		return 4*getSide();
	}
	
	public double getArea() {
		return getSide()*getSide();
	}

	@Override
	public String toString() {
		return "Square [getSide()=" + getSide() + ", getPerimeter()=" + getPerimeter() + ", getArea()=" + getArea()
				+ ", getColor()=" + getColor() + ", isFilled()=" + isFilled() + "]";
	}
	
}
