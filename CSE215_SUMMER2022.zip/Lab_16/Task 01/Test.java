
public class Test {

	public static void main(String[] args) {
		// Shape s = new Shape(); //Abstract class can not be instantiated

		Shape s1 = new Circle(4.0, "blue", true); // Upcasting Circle to Shape
		System.out.println("Color: " + s1.getColor());
		System.out.println("Filled: " + s1.isFilled());
		// System.out.println("Radius: " + s1.getRadius()); //This method does not exist
		// in the Superclass Shape
		System.out.println("Area: " + s1.getArea());
		System.out.println("Perimeter: " + s1.getPerimeter());
		System.out.println();

		if (s1 instanceof Circle) {
			Circle c1 = (Circle) s1; // Downcast back to Circle
			System.out.println("Color: " + c1.getColor());
			System.out.println("Filled: " + c1.isFilled());
			System.out.println("Radius: " + c1.getRadius());
			System.out.println("Area: " + c1.getArea());
			System.out.println("Perimeter: " + c1.getPerimeter());
			System.out.println();

		}

		Shape s2 = new Rectangle(4.0, 6.0, "blue", true); // Upcasting Rectangle to Shape
		System.out.println("Color: " + s2.getColor());
		System.out.println("Filled: " + s2.isFilled());
		// System.out.println("Width: " + s2.getWidth()); //This method does not exist
		// in the Superclass Shape
		// System.out.println("Length: " + s2.getLength()); //This method does not exist
		// in the Superclass Shape
		System.out.println("Area: " + s2.getArea());
		System.out.println("Perimeter: " + s2.getPerimeter());
		System.out.println();

		if (s2 instanceof Rectangle) {
			Rectangle r1 = (Rectangle) s2; // Downcast back to Rectangle
			System.out.println("Color: " + r1.getColor());
			System.out.println("Filled: " + r1.isFilled());
			System.out.println("Width: " + r1.getWidth());
			System.out.println("Length: " + r1.getLength());
			System.out.println("Area: " + r1.getArea());
			System.out.println("Perimeter: " + r1.getPerimeter());
			System.out.println();

		}
	}

}
