package tasks;

public class Main {
    public static void main(String[] args) {
        PartTimeEmployee pte = new PartTimeEmployee("Abir Mahmud", 25, "Mirpur", "ECE", "Program Officer", 20, 80);
        System.out.println(pte);
        System.out.println();

        FullTimeEmployee fte = new FullTimeEmployee("Ahsanur Rahman", 28, "Bashundhara R/A", "ECE", "Professor", 15000,
                25);
        System.out.println(fte);
        System.out.println();
    }
}
