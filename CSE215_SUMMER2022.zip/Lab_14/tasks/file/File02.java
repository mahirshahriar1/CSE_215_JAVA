import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class File02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Quiz[] quiz = new Quiz[100];
		int numOfStudent = 0;
		
		File fileObj = new File("Marks.txt");
		try {
			Scanner fr = new Scanner(fileObj);
			while(fr.hasNextLine()) {
				try {
					int id = Integer.parseInt(fr.next());
					int marks = Integer.parseInt(fr.next());
					quiz[numOfStudent++] = new Quiz(id, marks);
				}catch(Exception e) {
					//e.printStackTrace();
				}
				
			}
			fr.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(int i = 0; i < numOfStudent ; i++)
			System.out.println(quiz[i].toString());
		
		int index = getIndexOfHighestMark(quiz, numOfStudent);
		
		System.out.println("Highest mark obtained by ID:" + quiz[index].getId());
	}
	
	public static int getIndexOfHighestMark(Quiz[] records, int noOfStudent) {
		int highest = records[0].getMark();
		int index  = 0;
		for(int i = 1; i < noOfStudent; i++) {
			if(records[i].getMark() > highest) {
				index = i;
			}
		}
		
		return index;
	}
	

}
