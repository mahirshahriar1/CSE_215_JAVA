
public class Quiz {
	private int id, mark;

	public Quiz(int id, int mark) {
		
		this.id = id;
		this.mark = mark;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMark() {
		return mark;
	}

	public void setMark(int mark) {
		this.mark = mark;
	}

	@Override
	public String toString() {
		return "Id : " + id + " Mark : " + mark;
	}
	
	
}
