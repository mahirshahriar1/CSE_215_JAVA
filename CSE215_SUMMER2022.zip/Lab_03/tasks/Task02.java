package Lab_03.tasks;

import java.util.Scanner;

public class Task02 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("N = ");
        int N = sc.nextInt();
        sc.close();
        double sum = 0;
        for (int i = 1; i <= N; i++)
            sum += 1.0 / i;
        System.out.printf("Summation : %.2f\n", sum);
    }
}
