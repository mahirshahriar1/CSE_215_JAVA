package Lab_03.tasks;

import java.util.Scanner;

public class Task01 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter N: ");
        int N = sc.nextInt();
        sc.close();

        int i = 1, count = 0;

        while (i <= N) {

            if (N % i == 0)
                count++;
            i++;
        }
        System.out.println(N + " has total " + count + " factors.");
    }
}
