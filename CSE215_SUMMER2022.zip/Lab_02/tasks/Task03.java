package Lab_02.tasks;

import java.util.Scanner;

public class Task03 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter operator: ");
        char ch = sc.next().charAt(0);

        System.out.println("Enter 1st Operand: ");
        float a = sc.nextFloat();

        System.out.println("Enter 2nd Operand: ");
        float b = sc.nextFloat();

        sc.close();

        switch (ch) {
            case '+':
                System.out.printf("%.2f + %.2f = %.2f\n", a, b, a + b);
                break;
            case '-':
                System.out.printf("%.2f - %.2f = %.2f\n", a, b, a - b);
                break;
            case '*':
                System.out.printf("%.2f * %.2f = %.2f\n", a, b, a * b);
                break;
            case '/':
                System.out.printf("%.2f / %.2f = %.2f\n", a, b, a / b);
                break;

            default:
                System.out.println("Please, Enter a valid operator.");
                break;
        }

    }
}
