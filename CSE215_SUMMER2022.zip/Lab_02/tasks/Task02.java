package Lab_02.tasks;

import java.util.Scanner;

public class Task02 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("First person: ");

        System.out.println("Enter feet: ");
        int f1 = sc.nextInt();
        System.out.println("Enter inch: ");
        int i1 = sc.nextInt();

        System.out.println("Enter feet: ");
        int f2 = sc.nextInt();
        System.out.println("Enter inch: ");
        int i2 = sc.nextInt();

        sc.close();

        int d1 = f1 * 12 + i1;
        int d2 = f2 * 12 + i2;

        int res = (d1 > d2) ? d1 - d2 : d2 - d1;
        System.out.println("Difference: " + res / 12 + " feet " + res % 12 + " inch.");
    }
}
