package Lab_02.tasks;

import java.util.Scanner;

public class Task04 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your anual income: ");
        double income = sc.nextDouble();
        sc.close();

        double tax = (income <= 100000) ? 100000 * 0.1 : (income * 0.1) + ((income - 100000) * 0.2);

        System.out.printf("Eligible tax amount is : %,.4f\n", tax);
    }
}
