package tasks;

public class Course {

    private String courseName;
    private String[] students;
    private int numberOfStudents;

    public Course(String courseName) {
        this.courseName = courseName;
        students = new String[3];
        numberOfStudents = 0;
    }

    public String getCourseName() {
        return courseName;
    }

    public void addStudent(String student) {
        if (numberOfStudents == students.length) {
            String[] temp = new String[numberOfStudents + 1];
            for (int i = 0; i < numberOfStudents; i++) {
                temp[i] = students[i];
            }
            students = temp;
            temp = null;
        }
        students[numberOfStudents++] = student;

    }

    public void dropStudent(String student) {
        int index = getStudentIndex(student);
        if (index >= 0) {
            for (int i = index; i < numberOfStudents - 1; i++) {

                students[i] = students[i + 1];
            }
            students[--numberOfStudents] = null;
        } else {
            System.out.println("No Student Has Been Found With This Name:" + student);
        }
    }

    public int getStudentIndex(String student) {
        for (int i = 0; i < numberOfStudents; i++) {
            if (students[i].equals(student)) {
                return i;
            }
        }
        return -1;
    }

    public String[] getStudents() {
        return students;
    }

    public int getNumberOfStudents() {
        return numberOfStudents;
    }

    public void clear() {
        String[] temp = new String[3];
        students = temp;
        numberOfStudents = 0;
    }
}
