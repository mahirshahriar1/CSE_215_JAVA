package tasks;

public class TestCourse {
    public static void main(String[] args) {
        Course cse215 = new Course("Programming Language-II");

        // Initially 3 Students Are Added
        cse215.addStudent("Batman");
        cse215.addStudent("Iron Man");
        cse215.addStudent("Spiyder Man");

        System.out.println("Registered Students of " + cse215.getCourseName() + ":");
        String[] temp = cse215.getStudents();
        int numOfStudents = cse215.getNumberOfStudents();
        for (int i = 0; i < numOfStudents; i++) {
            System.out.println(temp[i]);
        }
        System.out.println();

        // 2 More Students Are Added
        cse215.addStudent("Supper Man");
        cse215.addStudent("Hulk");

        System.out.println("Registered Students of " + cse215.getCourseName() + ":");
        temp = cse215.getStudents();
        numOfStudents = cse215.getNumberOfStudents();
        for (int i = 0; i < numOfStudents; i++) {
            System.out.println(temp[i]);
        }
        System.out.println();

        // 1 Student is dropped
        cse215.dropStudent("Supper Man");

        System.out.println("Registered Students of " + cse215.getCourseName() + ":");
        temp = cse215.getStudents();
        numOfStudents = cse215.getNumberOfStudents();
        for (int i = 0; i < numOfStudents; i++) {
            System.out.println(temp[i]);
        }
        System.out.println();
    }

}
