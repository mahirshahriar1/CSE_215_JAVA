package main;

public interface Genre {
	
	double getGenreDiscount();
	String getSubGenre();
	void setSubGenre(String subGenre);
	String getGenre();
}
