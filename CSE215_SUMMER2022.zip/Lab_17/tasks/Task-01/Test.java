
public class Test {

	public static void main(String[] args) {
		MovablePoint mp = new MovablePoint(1, 2, 1, 1);
		System.out.println(mp);
		mp.moveUp();
		System.out.println(mp);
		System.out.println();
		
		MovableCircle mc = new MovableCircle(2, 1, 1, 1, 5);
		System.out.println(mc);
		mc.moveRight();
		System.out.println(mc);
		
	}

}
