
public class Test {

	public static void main(String[] args) {
		Circle c = new Circle(5.0);
		System.out.println("Radius: " + c.radius);
		System.out.println("Perimeter: " + c.getPerimeter());
		System.out.println("Area: " + c.getArea());
		System.out.println();
		
		ResizableCircle rc = new ResizableCircle(6.0);
		System.out.println("Radius: " + rc.radius);
		System.out.println("Perimeter: " + rc.getPerimeter());
		System.out.println("Area: " + rc.getArea());
		System.out.println();
		
		rc.resize(50);
		System.out.println("Radius: " + rc.radius);
		System.out.println("Perimeter: " + rc.getPerimeter());
		System.out.println("Area: " + rc.getArea());
		System.out.println();
	}

}
