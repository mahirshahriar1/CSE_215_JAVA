
public class DelimiterMatching {

	public boolean isDelimiterMatching(String str) {
		Stack s = new Stack(str.length());

		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);

			if (ch == '(' || ch == '{' || ch == '[')
				s.push(ch);

			if (ch == ')' || ch == '}' || ch == ']') {
				if (!s.isStackEmpty()) {
					char item = s.pop();
					if ((ch == ')' && item != '(') || (ch == '}' && item != '{') || (ch == ']' && item != '['))
						return false;

				}

			}
		}

		if (!s.isStackEmpty())
			return false;

		return true;
	}
}
