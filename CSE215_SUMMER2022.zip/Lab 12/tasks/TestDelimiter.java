import java.util.Scanner;

public class TestDelimiter {

	public static void main(String[] args) {
		String str;
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter an stression: ");
		str = sc.nextLine();

		DelimiterMatching dm = new DelimiterMatching();
		boolean result = dm.isDelimiterMatching(str);

		System.out.println(str + " ==> " + result);
	}

}
