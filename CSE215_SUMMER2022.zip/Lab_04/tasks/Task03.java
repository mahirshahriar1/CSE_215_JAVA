package Lab_04.tasks;

import java.util.Scanner;

public class Task03 {
    @SuppressWarnings("unused")
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("num = ");
        int digit = sc.nextInt();
        sc.close();
        System.out.println("Sum of digits: " + sumDigit(digit));
    }

    public static int sumDigit(int number) {
        int sum = 0, d;
        while (number > 0) {

            // calculate last digit
            d = number % 10;
            // adds last digit to the variable sum
            sum = sum + d;
            // removes the last digit from the number
            number = number / 10;
        }

        return sum;
    }
}
