
public class Test {

	public static void main(String[] args) {
		Circle c1 = new Circle();
		System.out.println(c1 + " ==> Area: " + c1.getArea());
	
		Circle c2 = new Circle(2.0, "blue");
		System.out.println(c2 + " ==> Area: " + c2.getArea());
		
		System.out.println();
		
		Cylinder cy1 = new Cylinder();
		System.out.println(cy1 + " ==> Volume: " + cy1.getVolume());
		
		Cylinder cy2 = new Cylinder(4.0);
		System.out.println(cy2 + " ==> Volume: " + cy2.getVolume());
		
		Cylinder cy3 = new Cylinder(4.0, 2.0);
		System.out.println(cy3 + " ==> Volume: " + cy3.getVolume());
		
		Cylinder cy4 = new Cylinder(4.0, 2.0, "violet");
		System.out.println(cy4 + " ==> Volume: " + cy4.getVolume());

	}

}
