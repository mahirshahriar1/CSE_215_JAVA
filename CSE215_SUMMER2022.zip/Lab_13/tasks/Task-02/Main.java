
public class Main {

	public static void main(String[] args) {
		Circle c1 = new Circle(5.0, "Blue", true);
		c1.printCircle();
		System.out.println("Area: " + c1.getArea());
		System.out.println("Perimeter: " + c1.getPerimeter());
		System.out.println();
		
		Rectangle r1 = new Rectangle(3.0, 4.0);
		r1.printRectangle();
		System.out.println("Area: " + r1.getArea());
		System.out.println("Perimeter: " + r1.getPerimeter());
		System.out.println();
		
	}

}
