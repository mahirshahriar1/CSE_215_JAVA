
public class Main {

	public static void main(String[] args) {
		Book b1 = new Book("Digital Logic Design", "M. Morris Mano");
		Book b2 = new Book("Database Systems", "Elmasri Navathe");
		
		Product p1 = new Product("Savlon", 1, 45);
		Product p2 = new Product("Nivea Lotion", 2, 350);
		
		GenericStack<Book> bookStack = new GenericStack<Book>();
		GenericStack<Product> productStack = new GenericStack<Product>();
		
		bookStack.push(b2);
		bookStack.push(b1);
		
		productStack.push(p2);
		productStack.push(p1);
		
		System.out.println(bookStack);
		System.out.println();
		
		System.out.println(productStack);
		System.out.println();
	}

}
