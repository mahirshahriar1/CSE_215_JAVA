import java.util.ArrayList;

public class GenericStack<T> {

	private ArrayList<T> list;

	public GenericStack() {
		list = new ArrayList<T>();
	}

	public int getSize() {
		return list.size();
	}

	public T peek() {
		return list.get(getSize() - 1);
	}

	public T pop() {
		T item = peek();
		list.remove(getSize() - 1);
		return item;
	}

	public void push(T o) {
		list.add(o);
	}

	public boolean isEmpty() {
		return list.isEmpty();
	}

	@Override
	public String toString() {
		String item = "";
		while (!isEmpty()) {
			item = item + pop() + "\n";
		}

		return item;
	}
}
