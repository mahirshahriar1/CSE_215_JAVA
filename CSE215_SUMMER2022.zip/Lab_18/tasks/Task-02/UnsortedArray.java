public class UnsortedArray<E> {
    private final static int MAX_ITEMS = 5;
    private int length, currentPos;
    E[] info = (E[]) new Object[MAX_ITEMS];

    public UnsortedArray() {
        this.length = 0;
        this.currentPos = -1;
    }

    public void makeEmpty() {
        length = 0;
    }

    public boolean isFull() {
        return (length == MAX_ITEMS);
    }

    public int lengthIs() {
        return length;
    }

    public void resetList() {
        currentPos = -1;
    }

    public E getNextItem() {
        return (E) info[++currentPos];
    }

    public void insertItem(E item) {
        info[length++] = item;
    }

    public void deleteItem(E item) {
        int index = getStudentIndex(item);
        if (index >= 0)
            info[index] = info[length - 1];
        length--;
    }

    public int getStudentIndex(E item) {
        for (int i = 0; i < length; i++) {
            if (info[i].equals(item)) {
                return i;
            }
        }
        return -1;
    }

    public boolean RetrieveItem(E item) {
        boolean isFound = false;
        int index = getStudentIndex(item);
        if (index >= 0) {
            isFound = true;
        }
        return isFound;
    }
}