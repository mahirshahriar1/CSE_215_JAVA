public class Main {
    public static void main(String[] args) {
        UnsortedArray<Integer> arr = new UnsortedArray<Integer>();

        arr.insertItem(5);
        arr.insertItem(7);
        arr.insertItem(6);
        arr.insertItem(9);

        for (int i = 0; i < arr.lengthIs(); i++) {
            System.out.println(arr.getNextItem());
        }

        System.out.println("Length is : " + arr.lengthIs());

        arr.insertItem(1);

        if (arr.RetrieveItem(4) == true)
            System.out.println("Item is found");
        else
            System.out.println("item is not found");

        if (arr.RetrieveItem(5) == true)
            System.out.println("Item is found");
        else
            System.out.println("item is not found");

        if (arr.RetrieveItem(9) == true)
            System.out.println("Item is found");
        else
            System.out.println("item is not found");

        if (arr.RetrieveItem(10) == true)
            System.out.println("Item is found");
        else
            System.out.println("item is not found");

        if (arr.isFull() == true)
            System.out.println("List is full");
        else
            System.out.println("List is not full");

        arr.deleteItem(5);

        if (arr.isFull() == true)
            System.out.println("List is full");
        else
            System.out.println("List is not full");

        arr.deleteItem(1);
        arr.resetList();
        for (int i = 0; i < arr.lengthIs(); i++) {
            System.out.println(arr.getNextItem());
        }

        arr.deleteItem(6);
        arr.resetList();
        for (int i = 0; i < arr.lengthIs(); i++) {
            System.out.println(arr.getNextItem());
        }

        UnsortedArray<StudentInfo> student = new UnsortedArray<StudentInfo>();
        StudentInfo s1 = new StudentInfo(15234, "Jon", 2.6);
        StudentInfo s2 = new StudentInfo(13732, "Tyrion", 3.9);
        StudentInfo s3 = new StudentInfo(13569, "Sandor", 1.2);
        StudentInfo s4 = new StudentInfo(15467, "Ramsey 2", 3.1);
        StudentInfo s5 = new StudentInfo(16285, "Arya", 3.1);

        student.insertItem(s1);
        student.insertItem(s2);
        student.insertItem(s3);
        student.insertItem(s4);
        student.insertItem(s5);

        for (int i = 0; i < student.lengthIs(); i++) {
            System.out.println(student.getNextItem());
        }

        student.deleteItem(s4);
        if (student.RetrieveItem(s3) == true) {
            System.out.println("Item is found");
            s3.toString();
        } else
            System.out.println("item is not found");

        student.resetList();

        for (int i = 0; i < student.lengthIs(); i++) {
            System.out.println(student.getNextItem());
        }
    }
}
