
public class DepartmentStore {
	
	private String storeName;
	private String address;
	private Product[] productList;
	private int numberOfProducts;
	
	public DepartmentStore() {
		
	}

	public DepartmentStore(String storeName, String address) {
		this.storeName = storeName;
		this.address = address;
		productList = new Product[500];
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void addProduct(Product product) {
		if(numberOfProducts < 500) {
			productList[numberOfProducts++] = product;
		}
		else {
			System.out.println("Limit Exceeded");
		}
	}

	public int getProductIndex(Product product) {
		int index = -1;
		for(int i = 0; i < numberOfProducts; i++) {
			if(product.equals(productList[i])) {
				return i;
			}
		}
		return index;
	}
	
	public void removeProduct(Product product) {
		int index = getProductIndex(product);
		
		if(index >= 0) {
			for(int i = index; i < numberOfProducts - 1; i++) {
				productList[i] = productList[i + 1];
			}
			productList[numberOfProducts--] = null;
		}
		else {
			System.out.println("Product does not exist");
		}

	}
	
	public void searchProduct(Product product) {
		int index = getProductIndex(product);
		if(index >= 0) {
			System.out.println(productList[index]);
		}
		else {
			System.out.println("Product does not exist");
		}
	}
	
	@Override
	public String toString() {
		return "[Store Name: " + storeName + ", Address: " + address + "]";
	}
}
