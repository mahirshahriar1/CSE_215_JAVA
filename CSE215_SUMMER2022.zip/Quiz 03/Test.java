import java.util.Iterator;

public class Test {

	public static void main(String[] args) {
		DepartmentStore dStore = new DepartmentStore("All in One Store", "New market");
		
		Product p1 = new Product("Hexisol", "ACI", 130, 10, 1);
		Product p2 = new Product("Odomos", "Dabur", 240, 13, 2);
		Product p3 = new Product("Nivea Lotion", "Nivea", 730, 30, 3);
		Product p4 = new Product("Water Purifier", "Kent", 4300, 23, 4);
		
		dStore.addProduct(p1);
		dStore.addProduct(p2);
		dStore.addProduct(p3);
		dStore.addProduct(p4);
		
		dStore.removeProduct(p3);
		
		dStore.searchProduct(p4);
		
	}

}
