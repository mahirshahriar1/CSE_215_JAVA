
public class Product {
	
	private String productName;
	private String brandName;
	private int price;
	private int quantity;
	private int productId;

	public Product() {
		
	}

	public Product(String productName, String brandName, int price, int quantity, int productId) {
		this.productName = productName;
		this.brandName = brandName;
		this.price = price;
		this.quantity = quantity;
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	@Override
	public String toString() {
		return "Product [productName=" + productName + ", brandName=" + brandName + ", price=" + price + ", quantity="
				+ quantity + ", productId=" + productId + "]";
	}
	
}
